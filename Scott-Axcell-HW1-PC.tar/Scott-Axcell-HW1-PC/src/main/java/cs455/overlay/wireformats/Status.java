package cs455.overlay.wireformats;

public interface Status {
    int SUCCESS = 0;
    int FAILURE = 1;
}
